package com.example.controlui;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.ToggleButton;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    String[] arr = { "Aaryan Gupta", "Abhishek Singhal", "Aman Kumar", "Ankit Birla", "Avinash Kumar",
            "Ayush Sharma", "Bhanu Yadav", "Deepak Kaushik", "Deepak Kumar Sharma", "Himanshu Verma",
            "Jitendra Kumar", "Drashti Sharma", "Kamini Gautam", "Kritika Rajput", "Mehar Shree",
            "Paridhi Kaushik", "Parul", "Priyanshu Saxena", "Ravi Kumar", "Rudravir Singh",
            "Shobhit Sharma", "Subham Singh", "Suraj", "Suzan Khan", "Umesh", "Vikash Agrawal",
            "Ankit Singh", "Mohit Paras"
    };

    private AutoCompleteTextView Name;
    private ToggleButton Toggle;
    private EditText DOB;
    private EditText birthTime;
    private DatePickerDialog picker;
    private TimePickerDialog timepicker;
    private RadioGroup radioName;
    private RadioButton radioBtn;
    private CheckBox cbiot, cbrobo, cbai, cbml;
    private ImageButton submit;
    private Switch nightmode;

    private Spinner s;
    int getSelected;
    String text="";

    //Data for populating in Spinner
    String [] gen={"Choose your Gender...", "Male", "Female"};

    private TextView Text;
    private SeekBar bar;
    int textSize = 3;
    int saveProgress;
    boolean isDark = false;
    private ConstraintLayout back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = findViewById(R.id.main_name);
        Toggle = findViewById(R.id.toggle);
        DOB = findViewById(R.id.dob);
        DOB.setInputType(InputType.TYPE_NULL);
        birthTime = findViewById(R.id.time);
        birthTime.setInputType(InputType.TYPE_NULL);
        submit = findViewById(R.id.submitBtn);
        nightmode = findViewById(R.id.switch1);
        back = findViewById(R.id.background);

        radioName = (RadioGroup)findViewById(R.id.radioName);
        radioName.clearCheck();

        cbiot = (CheckBox) findViewById(R.id.cbiot);
        cbrobo = (CheckBox) findViewById(R.id.cbrobo);
        cbai = (CheckBox) findViewById(R.id.cbai);
        cbml = (CheckBox) findViewById(R.id.cbml);

        s= (Spinner) findViewById(R.id.spinner);

        //Creating Adapter for Spinner for adapting the data from array to Spinner
        ArrayAdapter adapter1= new ArrayAdapter(MainActivity.this,android.R.layout.simple_spinner_item, gen);
        s.setAdapter(adapter1);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item, arr);

        Name.setThreshold(1);
        Name.setAdapter(adapter);

        Text = findViewById(R.id.text);
        bar = findViewById(R.id.seekBar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                textSize = textSize + (progress-saveProgress);
                saveProgress = progress;
                Text.setTextSize(textSize);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        isDark = getThemeStatePref();
        if(isDark) {
            // dark theme is on

            back.setBackgroundColor(getResources().getColor(R.color.black));

        }
        else
        {
            // light theme is on
            back.setBackgroundColor(getResources().getColor(R.color.white));

        }

        nightmode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    // The toggle is enabled
                    back.setBackgroundColor(getResources().getColor(R.color.black));

                } else {
                    // The toggle is disabled
                    back.setBackgroundColor(getResources().getColor(R.color.white));
                }
                saveThemeStatePref(isDark);
            }
        });

        Toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    Text.setText("Hello there!");

                } else {
                    // The toggle is disabled
                    Text.setText("Hii there!");
                }
            }
        });

        DOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                DOB.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });

        birthTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int hour = cldr.get(Calendar.HOUR_OF_DAY);
                int minutes = cldr.get(Calendar.MINUTE);
                // time picker dialog
                timepicker = new TimePickerDialog(MainActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                                birthTime.setText(sHour + ":" + sMinute);
                            }
                        }, hour, minutes, true);
                timepicker.show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(cbiot.isChecked())
                    text = text + " IoT ";
                if(cbrobo.isChecked())
                    text = text + " Robotics ";
                if(cbai.isChecked())
                    text = text + " AI ";
                if(cbml.isChecked())
                    text = text + " ML ";

                getSelected = radioName.getCheckedRadioButtonId();
                radioBtn = (RadioButton)findViewById(getSelected);

                StringBuffer buffer=new StringBuffer();

                buffer.append("Name: "+radioBtn.getText()+" "+Name.getText().toString()+"\n");
                buffer.append("Gender: "+s.getSelectedItem().toString()+"\n");
                buffer.append("Date of Birth:"+DOB.getText().toString()+" "+birthTime.getText().toString()+"\n");
                buffer.append("Subjects: "+text);

                showMessage("Your Details", buffer.toString());
            }

        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    private void saveThemeStatePref(boolean isDark) {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("myPref",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("isDark",isDark);
        editor.commit();
    }

    private boolean getThemeStatePref () {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("myPref",MODE_PRIVATE);
        boolean isDark = pref.getBoolean("isDark",false) ;
        return isDark;

    }
}
